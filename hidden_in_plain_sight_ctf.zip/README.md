# Hidden in Plain Sight

## Category: Forensics / Steganography
**Description:**

You came across this peaceful image, but someone said there's a secret hidden inside.
Can you find the hidden message?

> Format: flag{...}